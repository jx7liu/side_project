#include "decorator.h"

Decorator:: ~Decorator () {
delete component;
}
