

int rollDice ();
int rollDice2 ();
